//Create Global Variables
var myArray = [];
var xValues = [];
var width = 500;
var height = 380;

//Create Canvas and add rectangles
function startGame() {
  canvasArea.start();
  populate(12);
}

//Create initial array of rectangle components
function populate(num){
	for(let i = 0; i<num; i++){
		myArray[i] = new component(30, 30+30*i, "red",(10+40*i),340-30*i);
		xValues[i] = (10+40*i);
	}
}

//create canvas area based on certain width and height
var canvasArea = {
  canvas : document.createElement("canvas"),
  start : function() {
    this.canvas.width = width;
    this.canvas.height = height;
    this.context = this.canvas.getContext("2d");
    document.body.insertBefore(this.canvas, document.body.childNodes[0]);
  }
}

//Constructor for Rectangle component
function component(width, height, color, x, y) {
  this.width = width;
  this.height = height;
  this.x = x;
  this.y = y;
  ctx = canvasArea.context;
  ctx.fillStyle = color;
  ctx.fillRect(this.x, this.y, this.width, this.height);
}

//Randomize's order of rectangles on the canvas
function randomize(){
	ctx.clearRect(0,0,width,height);
	xValues.sort(function(a, b){return 0.5 - Math.random()});

	for(let i =0; i<myArray.length;i++){
		myArray[i].x = xValues[i];
		ctx.fillRect(myArray[i].x, myArray[i].y, myArray[i].width, myArray[i].height);
	}
}

//Reverses the order of the rectangles on the canvas
function reversed(){
	ctx.clearRect(0,0,width,height);
	xValues.sort(function(a, b){return b-a});

	for(let i =0; i<myArray.length;i++){
		myArray[i].x = xValues[i];
		ctx.fillRect(myArray[i].x, myArray[i].y, myArray[i].width, myArray[i].height);
	}
}

//Puts the Rectangles in a semi-sorted order on the canvas
function semiSort(){
	ctx.clearRect(0,0,width,height);
	xValues = [130,170,210,10,50,90,370,410,450,250,290,330];

	for(let i =0; i<myArray.length;i++){
		myArray[i].x = xValues[i];
		ctx.fillRect(myArray[i].x, myArray[i].y, myArray[i].width, myArray[i].height);
	}
}

//Updates / Redraws the rectangles on the canvas based on a new order
//determined by the sorting algorithm selected
function updateCanvas(x){
	ctx.clearRect(0,0,width,height);

	for(let i =0; i<myArray.length;i++){
		ctx.fillRect(myArray[i].x, myArray[i].y, myArray[i].width, myArray[i].height);
	}
  //Displays the number of checks and swaps done by the chosen sorting algorithm
	document.getElementById("demo").innerHTML = "Number of checks: " +numChecks+ ". Number of swaps: " +numSwaps;
}

//Global Variables for counting checks and swaps
var numSwaps;
var numChecks;

//Global Variable for Bubble Sort
var swappBubble;

//Main bubble sort call, while the array is not sorted
function bubbleSort()
{
	numSwaps = 0;
	numChecks = 0;
    let n = myArray.length-1;
    let x=myArray;
    do {
        bubbleSwap(n,x);
        n--;
    } while (swappBubble);
}

//Pass array to be checked
function bubbleSwap(n,x){
	let count = 0;
  //check time for timeout
	let d = new Date();
	let startTime = d.getTime();
	let endTime;
  //Set interval between updates
	let interval = setInterval(function() {
		swappBubble = false;
    //Check through the array
		for (let i=0; i < n; i++)
		{
			numChecks++;
      //Swap the values if out of order
			if (x[i].x > x[i+1].x)
			{
			   let temp = x[i].x;
			   x[i].x = x[i+1].x;
			   x[i+1].x = temp;
			   swappBubble = true;
			   myArray = x;
			   numSwaps++;
         //Update the canvas image after swap
			   updateCanvas();
			}
		}
    //Check timeout endtime
		d = new Date();
		endTime = d.getTime();
    //Calculate runtime difference for termination
		if(endTime-startTime > 4000)
		{
			clearInterval(interval)
		}
	},300);
}

//Insertion sort main function
function insertionSort() {

//Replace for loop with Interval loop and counter varaiable
	let i = 0;
	numSwaps = 0;
	numChecks = 0;
	let interval = setInterval(function(){

//Check first item, sort through array backwards shifting down until in right place
	let currentUnsortedItem = xValues[i];
	numChecks++;
	for (var j = i; j > 0 && currentUnsortedItem < xValues[j - 1]; j--) {
		numSwaps++;
		numChecks++;
	  xValues[j] = xValues[j - 1];
	}

  //Check next value
	xValues[j] = currentUnsortedItem;

  //Replace X component of rectangle
	for(let k =0; k<myArray.length;k++){
		myArray[k].x = xValues[k];
	}

  //Update the canvas
	updateCanvas();
	i++;

  //termination when array has been fully travered
	if(i >= myArray.length){
		clearInterval(interval);
	}
	},300);
}

//Selection Sort Call
function selectionSort() {
  let len = myArray.length;
	numSwaps = 0;
	numChecks = 0;

  //Replace For loop with interval loop and termination counter
	let i =0;
	let interval = setInterval(function()
  {
    //Ched first item against the rest of the array
    let j_min = i;
    for (let j = i + 1; j < len; j++)
    {
		    numChecks++;
        //Find the min element
        if (myArray[j].x < myArray[j_min].x)
        {
                j_min = j;
        }
    }
    //If the min element isnt unsorted against itself
    if (j_min != i)
    {
        numSwaps= numSwaps+2;
        swap(i, j_min);
    }

    //Stop interval once entire array has been checked through
		i++;
		if(i >= myArray.length){
		    clearInterval(interval);
		}
    },300);
}

//Swap the two elements of the array at pos X and Y
function swap(x, y) {
    let temp = myArray[x].x;
    myArray[x].x = myArray[y].x;
    myArray[y].x = temp;
	updateCanvas();
}
