import java.util.*;
import java.io.*;
public class Main{

  //global variables
  private static File original;
  private static File target;
  private static ArrayList<String> originalStrings = new ArrayList<String>();
  private static ArrayList<String> targetStrings = new ArrayList<String>();

  //get file directory from user
  public static void getFiles(String o, String t)
  {
    //create files
    original = new File(o);
    target = new File(t);
  }

  //read target file
  public static void readTarget() throws FileNotFoundException
  {
    //split target file up by word spaces read in UTF-8
    Scanner in = new Scanner((target),"ISO-8859-6").useDelimiter(" ");
    String str;

    //read each word
    while (in.hasNext())
    {
        str = in.next();
        //remove non ascii characters
        str = str.replaceAll("[^\\x00-\\x7F]", "");
        //remove ascii control characters
        str = str.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
        //remove nonprintable characters
        str = str.replaceAll("\\p{C}", "");
        //remove starting spaces
        str = str.replaceFirst("^ *", "");
        //remove punctuation marks
        str = str.replaceAll("\\p{Punct}", "");
        //remove new lines and returns
        str = str.replace("\n", "").replace("\r", "");
        //convert all to Lower Case
        str = str.toLowerCase();
        //add to array of words
        targetStrings.add(str);
    }
    //close scanner
    in.close();
    //remove any null values
    targetStrings.removeAll(Arrays.asList("", null));
  }

  //read the original file
  public static void readOriginal() throws FileNotFoundException
  {
    //split origiinal file by word spaces, read in UTF-8
    Scanner in = new Scanner((original),"ISO-8859-6").useDelimiter(" ");
    String str;

    //read each word
    while (in.hasNext())
    {
      str = in.next();
      //remove non ascii chracters
      str = str.replaceAll("[^\\x00-\\x7F]", "");
      //remove ascii control character
      str = str.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
      //remove non printable characters
      str = str.replaceAll("\\p{C}", "");
      //remove starting spaces
      str = str.replaceFirst("^ *", "");
      //remove punctuation marks
      str = str.replaceAll("\\p{Punct}", "");
      //remove new lines and returns
      str = str.replace("\n", "").replace("\r", "");
      //convert all to Lower Case
      str = str.toLowerCase();
      //add to array of words
      originalStrings.add(str);
  }
  //close scanner
  in.close();
  //remove any null values
  originalStrings.removeAll(Arrays.asList("", null));
  }

  //calculate the similarity score
  public static double calculateScore(ArrayList<String> o, ArrayList<String> t)
  {
    //declared variables
    int pointer = 0;
    int total = 0;
    int returnPtr = 0;

    //loop through both arrays of words
    for(int i = 0; i < o.size(); i++)
    {
      for(int j = 0; j < t.size(); j++)
      {
        /*
        *Check for 3 or more matching words
        *in a row, then add them to the total
        *if not, return the indexes to the original spot
        */
        if(!o.get(i).equals(t.get(j)))
        {
          //if more than 2 words in a row
          if(pointer > 2)
          {
            //add to total and reset the pointer
            total+=pointer;
            pointer = 0;
          }
          //if not more then 2 words in a row
          else if (pointer >= 1)
          {
            //reset the pointer and reset the index
            pointer = 0;
            i = returnPtr;
            if(i < o.size()-1)
            {
              i++;
            }
          }
        }
        //if the words match
        else
        {
          //set the return pointer
          returnPtr = i;
          //increment the pointer
          pointer++;
          //increase the iterator
          if(i < o.size()-1)
          {
            i++;
          }
        }
        //if reached the end of the target file, but not the original file
        if((j == t.size()-1) && (i != t.size()-1))
        {
          //increment the iterator
          i++;
        }
      }
    }
    //if the pointer has any leftover values
    if(pointer > 2)
      total+=pointer;

    //return the percent between 0 and 1
    return (double) total/t.size();
  }

  //main function
  public static void main(String[] args)
  {
    //read file directory as string
    String o = args[0];
    String t = args[1];
    //get directories
    getFiles(o,t);
    //try to read both files
    try
    {
      readTarget();
      readOriginal();
    }
    //catch Exceptions
    catch (FileNotFoundException e) {
      System.out.println(e);
    }
    //get and print score
    double score = calculateScore(originalStrings,targetStrings);
    int temp = (int)(score*1000);
    score = (double)temp;
    score = score/1000;
    System.out.print(score+",");
  }
}
