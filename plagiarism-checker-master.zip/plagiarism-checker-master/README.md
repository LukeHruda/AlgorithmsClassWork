# plagiarism-checker
##How create .jar file

1. Open cmd
2. Put your Java class file on your desktop (it's just easier)
3. cd Desktop in the command prompt
4. Type "jar -cvfe HelloWorld.jar HelloWorld HelloWorld.class" give your class file is HelloWorld.class
